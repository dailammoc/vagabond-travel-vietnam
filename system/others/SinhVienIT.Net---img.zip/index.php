<?php
  $bg = imagecreatefrompng("bg.png");
  $smile= imagecreatefrompng("smile.png");
  imagecopymerge($bg, $smile, 100, 100, 0, 0, 256, 256, 100);
  header('Content-type: image/png');
  $name = rand(1,9999).mktime();
  imagepng($bg,"img/".$name.mktime().".png");
  imagedestroy($bg);
  imagedestroy($smile);
  
?> 